# web_handle.py: Handle CHARMM-GUI login and session via Selenium
import os
import json
import time
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.common.exceptions import WebDriverException, NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# Configuration directory and cookie storage
CONFIG_DIR = Path.home() / ".bpcss"
COOKIE_FILE = CONFIG_DIR / "charmm_cookies.json"

# CHARMM-GUI URLs
CHARMM_GUI_BASE = "https://charmm-gui.org/"
# If there is a direct login URL, one can specify here; otherwise base URL suffices for manual login
CHARMM_LOGIN_URL = CHARMM_GUI_BASE

# Timeout settings
LOGIN_CHECK_INTERVAL = 30  # seconds between checks
MAX_LOGIN_WAIT = 300      # maximum seconds to wait for login


def ensure_config_dir():
    """Ensure the configuration directory exists."""
    try:
        CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    except Exception as e:
        print(f"Warning: could not create config directory {CONFIG_DIR}: {e}")


def load_cookies():
    """Load cookies from COOKIE_FILE if available."""
    if COOKIE_FILE.exists():
        try:
            with open(COOKIE_FILE, 'r') as f:
                cookies = json.load(f)
            return cookies
        except Exception as e:
            print(f"Failed to load cookies: {e}")
    return None


def save_cookies(cookies):
    """Save cookies to COOKIE_FILE."""
    ensure_config_dir()
    try:
        with open(COOKIE_FILE, 'w') as f:
            json.dump(cookies, f)
        print(f"Session cookies saved to {COOKIE_FILE}")
    except Exception as e:
        print(f"Failed to save cookies: {e}")


def is_logged_in(driver):
    """Heuristic to detect if user is logged in to CHARMM-GUI.
    Tries to find a 'Logout' link or user-specific element.
    """
    try:
        # Look for link or button containing 'Logout' text
        elems = driver.find_elements(By.PARTIAL_LINK_TEXT, "Logout")
        if elems:
            return True
        # Alternative: look for account/profile indicator
        elems2 = driver.find_elements(By.PARTIAL_LINK_TEXT, "Sign Out")
        if elems2:
            return True
    except Exception:
        pass
    return False


def charmm_login():
    """Launch Selenium browser, prompt user to login to CHARMM-GUI, detect success, and store session cookies."""
    ensure_config_dir()
    # Initialize WebDriver (Chrome by default)
    try:
        driver = webdriver.Chrome()
    except WebDriverException as e:
        print("Failed to start WebDriver (Chrome). Ensure ChromeDriver is installed and in PATH.")
        print(f"Error: {e}")
        return None

    driver.maximize_window()
    # Navigate to CHARMM-GUI
    try:
        driver.get(CHARMM_LOGIN_URL)
    except Exception as e:
        print(f"Failed to navigate to CHARMM-GUI: {e}")
        driver.quit()
        return None

    # Attempt to load existing cookies
    cookies = load_cookies()
    if cookies:
        for ck in cookies:
            # Adjust domain if necessary; Selenium may require domain matching the site
            try:
                driver.add_cookie(ck)
            except Exception:
                pass
        try:
            driver.refresh()
        except Exception:
            pass
        # After refresh, check if already logged in
        if is_logged_in(driver):
            print("Already logged into CHARMM-GUI using saved session.")
            return driver

    # Otherwise, prompt user to login manually
    print("Please log in to CHARMM-GUI in the opened browser window.")
    # Wait until login detected or timeout
    start_time = time.time()
    while True:
        elapsed = time.time() - start_time
        if elapsed > MAX_LOGIN_WAIT:
            print("Login not detected within timeout. You may continue manually or re-run later.")
            break
        time.sleep(LOGIN_CHECK_INTERVAL)
        try:
            driver.refresh()
        except Exception:
            pass
        if is_logged_in(driver):
            print("Login detected!")
            break
    # After login (or timeout), store cookies for future
    try:
        session_cookies = driver.get_cookies()
        save_cookies(session_cookies)
    except Exception as e:
        print(f"Failed to retrieve/save cookies: {e}")
    return driver


def interact_with_charmm_gui(driver):
    """Placeholder: further interactions with CHARMM-GUI after login.
    For example, upload PDB, configure settings, etc.
    This function should be extended as needed.
    """
    if driver is None:
        print("No valid WebDriver session.")
        return
    print("CHARMM-GUI session ready. You may automate further steps here.")
    # Example: navigate to specific input form
    # driver.get('https://charmm-gui.org/?doc=input')
    # TODO: add automation steps (e.g., file upload via Selenium)


if __name__ == '__main__':
    # Simple CLI for testing
    drv = charmm_login()
    if drv:
        interact_with_charmm_gui(drv)
        input("Press Enter to close browser...")
        drv.quit()

